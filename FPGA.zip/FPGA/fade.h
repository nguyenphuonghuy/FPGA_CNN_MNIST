#ifndef __FADE_H
#define __FADE_H

#include <stdint.h>

extern void fade( uint16_t * img1, uint16_t * img2, uint16_t * dest, uint16_t step, uint32_t pixels );

#endif
