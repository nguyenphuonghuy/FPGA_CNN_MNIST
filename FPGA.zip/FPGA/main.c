/*****************************************************************************
|*  FPGA_CNN_MNIST
|*
|* Devices:
|*  - LEDs and switches (WB_PRTIO)
|*  - TFT screen (VGA32_TFT)
|*  - JPEG decoder (WB_JPGDEC)
|*  - SD card (SPI_W + SD_CARD)
|*
|* Services used:
|*  - FAT filesystem (fs_fat)
|*  - VGA
|*  - PAL (processor abstraction layer)
|*
|*
\*****************************************************************************/
#include <stdio.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>

#include <drv_jpgdec.h>
#include <per_ioport.h>
#include <drv_vga_tft.h>
#include <fs.h>
#include <dirent.h>
#include <sys/stat.h>
#include <timing.h>
#define IMAGE_DIM 28
#define CONV_CORE_DIM 3
#define CONV_RANGE 1
#define CONV_MID 1
#define CONV1_OUT_DIM 8
#define CONV2_OUT_DIM 4
#define FC1_OUT_DIM 32
#define FC2_OUT_DIM 10

#define RELU(x) (((x)>0)?(x):(0))

double Input_Image[IMAGE_DIM][IMAGE_DIM];
double Conv1_W[CONV_CORE_DIM][CONV_CORE_DIM][1][CONV1_OUT_DIM];
double Conv1_B[CONV1_OUT_DIM];
double Conv1_Image[IMAGE_DIM][IMAGE_DIM][CONV1_OUT_DIM];
double Pool1_Image[IMAGE_DIM / 2][IMAGE_DIM / 2][CONV1_OUT_DIM];
double Conv2_W[CONV_CORE_DIM][CONV_CORE_DIM][CONV1_OUT_DIM][CONV2_OUT_DIM];
double Conv2_B[CONV2_OUT_DIM];
double Conv2_Image[IMAGE_DIM / 2][IMAGE_DIM / 2][CONV2_OUT_DIM];
double Pool2_Image[IMAGE_DIM / 4][IMAGE_DIM / 4][CONV2_OUT_DIM];
double Flat_Image[(IMAGE_DIM / 4)*(IMAGE_DIM / 4)*CONV2_OUT_DIM];
double Fc1_W[(IMAGE_DIM / 4)*(IMAGE_DIM / 4)*CONV2_OUT_DIM][FC1_OUT_DIM];
double Fc1_B[FC1_OUT_DIM];
double FC1_Image[FC1_OUT_DIM];
double Fc2_W[FC1_OUT_DIM][FC2_OUT_DIM];
double Fc2_B[FC2_OUT_DIM];
double FC2_Image[FC2_OUT_DIM];
double Softmax[FC2_OUT_DIM];
int ans;
int calc_cnt;

void Load_All();

// Convolution Layer 1 with relu
void Conv1();

// Max-pooling Layer 1
void MaxPool1();

// Convolution Layer 2 with relu
void Conv2();

// Max-pooling Layer 2
void MaxPool2();

// Flatten the image
void Flatten();

// FC Layer 1 with relu
void Fc1();

// FC Layer 2
void Fc2();

// Softmax and get the result
void Get_Answer();


#include "devices.h" // device IDs

#define MIN( A, B )         ((A)<(B)?(A):(B))
#define MODE_FADE           0x01
#define MODE_WAIT           0x02
#define MODE_NEXT           0x04

#define XRES_TFT            240
#define YRES_TFT            320
#define TFT_BUFSIZE         XRES_TFT * YRES_TFT
#define IMAGE_WIDTH  28  // Chi?u r?ng c?a ?nh
#define IMAGE_HEIGHT 28   // Chi?u cao c?a ?nh
#define MAX_CLUSTER_SIZE    4096

/*
 * The following storage must be located in external memory. This is achieved using the linker settings.
 */
#pragma section EXT_RAM
static uint8_t   diskbuf[MAX_CLUSTER_SIZE];
static uint16_t  image0[TFT_BUFSIZE] __align(4);
static uint16_t  image1[TFT_BUFSIZE] __align(4);
#pragma endsection

#pragma section EXT_RAM2
static uint16_t  tft_buf0[TFT_BUFSIZE] __align(4);
static uint16_t  tft_buf1[TFT_BUFSIZE] __align(4);
#pragma endsection

static uint8_t  modeswitches( uint8_t mode );
static void init( void );

volatile uint8_t    *diskstatus;
volatile uint8_t    *switches;
volatile uint8_t    *leds;
jpgdec_t            *jpgdec;
vga_tft_t           *tft;
uint16_t            *tft_buf;

void main( void )
{
          uint16_t** imageArray = (uint16_t**)malloc(IMAGE_HEIGHT * sizeof(uint16_t*));
    for (int i = 0; i < IMAGE_HEIGHT; i++) {
        imageArray[i] = (uint16_t*)malloc(IMAGE_WIDTH * sizeof(uint16_t));
    }
    uint16_t            * curimg;            // Points to the current image
    uint16_t            * nextimg;           // Points to the next image
    uint8_t             mode;

    DIR                 *dir;
    struct dirent       *dirent;
    struct stat         statbuf;
    int                 jpgfile;
    size_t              filesize;

    mode         = MODE_FADE | MODE_WAIT;

    init();
    curimg       = image0;
    nextimg      = image1;
    vga_tft_set_screen(tft, (uintptr_t)tft_buf0);
    tft_buf = tft_buf1;

    // Mount filesystem
    *diskstatus = 0;
    do
    {
        // Try to mount first partition, if that does not succeed, try to mount the whole disk
        if ( mount("/dev/BLOCKIO_1", "/sdcard", "fatfs", 1, MOUNT_FLAG_RDONLY) == 0 ) break;
    } while( mount("/dev/BLOCKIO_1", "/sdcard", "fatfs", 0, MOUNT_FLAG_RDONLY) != 0 );

    *diskstatus = 1;

    if ( chdir("/sdcard") != 0)
    {
        exit(1);
    }

    /* main loop */
    while( 1 )
    {

        dir = opendir("");

        while( dirent = readdir(dir), dirent )
        {
            mode &= ~MODE_NEXT;
            *leds = mode;

            if ( !strstr( dirent->d_name, "JPG" ) && !strstr( dirent->d_name, "jpg" )  )
            {
                continue;
            }

            if ( stat(dirent->d_name, &statbuf) != 0 )
            {
                continue;
            }
            filesize = statbuf.st_size;

            jpgfile = open(dirent->d_name, O_RDONLY);

            if ( jpgfile < 0 )
            {
                continue;
            }

            jpgdec_set_area(jpgdec, 0, 0, XRES_TFT, YRES_TFT );
            jpgdec_set_outputbuffer( jpgdec, (uintptr_t)nextimg,
                                     vga_tft_get_width( tft ) * vga_tft_get_height( tft ) * sizeof(uint16_t),
                                     vga_tft_get_width( tft ) );
            jpgdec_decode(jpgdec, 0, 0, 0);

            for (;;)
            {
                uint32_t status = jpgdec_get_status(jpgdec);

                if (status & JPGDEC_STATUS_READY)
                {
        //            finished!
                    break;
                }

                if (status & JPGDEC_STATUS_READEMPTY)
                {
                    if (filesize > 0)
                    {
                        int readsize = MIN( filesize, sizeof( diskbuf ));
                        read( jpgfile, diskbuf, readsize );
                        jpgdec_set_inputdata(jpgdec, diskbuf, readsize);
                        jpgdec_decode_continue(jpgdec, 0);
                        continue;
                    }
                    else
                    {
//                        print_status("JPG truncated, abort\n");
                        break;
                    }
                }

                if ( status != 0 )
                {
                    // unexpected
                    break;
                }
            }
            close( jpgfile );
            *diskstatus = 0;

            mode = modeswitches( mode );

            // switch display or crossfade

            // wait for keypress when in pause mode
            while (mode == 0)
            {
                mode = modeswitches( mode );
            }

            curimg = (curimg == image1) ? image0 : image1;
            nextimg = (nextimg == image1) ? image0 : image1;
               vga_tft_set_screen( tft, (uintptr_t)nextimg );
                tft_buf = tft_buf == tft_buf0 ? tft_buf1 : tft_buf0;
        }
        closedir(dir);
        convertImageTo2DArray(nextimg, imageArray);
    Conv1(imageArray);
    MaxPool1();
    Conv2();
    MaxPool2();
    Flatten();
    Fc1();
    Fc2();
    Get_Answer();

    int i;
    for (i = 0; i < 10; i++)
        printf("Number: %d, reliability: %f\n", i, (float)Softmax[i]);
    printf("Result = %d\n", ans);
    printf("Calculation times = %d\n", calc_cnt);
    getchar();
    }
}

/**********************************************************************
|*
|*  FUNCTION    : init
|*
|*  PARAMETERS  : None
|*
|*  RETURNS     : None
|*
|*  DESCRIPTION : Initialize the hardware and drivers
 */

static void init( void )
{
    // Initialize device drivers
    if ( tft = vga_tft_open(DRV_VGA_TFT_1 ), !tft )
    {
        abort();
    }

    if ( jpgdec = jpgdec_open( DRV_JPGDEC_1 ), !jpgdec )
    {
        abort();
    }

    if ( leds = (void *)per_ioport_get_base_address(PRTIO), !leds )
    {
        abort();
    }
    diskstatus = leds + 1;
    switches = diskstatus;

}

/**********************************************************************
|*
|*  FUNCTION    : modeswitches
|*
|*  PARAMETERS  : mode = current mode
|*
|*  RETURNS     : new mode
|*
|*  DESCRIPTION : change mode variable if user pressed any of the pushbuttons
 */
static uint8_t modeswitches( uint8_t mode )
{
    uint8_t pressed = ~ (*switches) & 0x1F;

     if (pressed & 0x02)
        mode = MODE_NEXT;
     else
            mode=0;
    *leds = mode;

    if (pressed)
    {
        while (~ (*switches) & 0x1F)
        {
            delay_ms(100);
        }
    }

    return mode;
}


void Conv1(imageArray) {
    int i, j, k;
    int i2, j2;
    double tmp_ans;
    for (i = 0; i < IMAGE_DIM; i++)
        for (j = 0; j < IMAGE_DIM; j++)
            for (k = 0; k < CONV1_OUT_DIM; k++) {
                tmp_ans = 0.0;
                for (i2 = -CONV_RANGE; i2 <= CONV_RANGE; i2++)
                    for (j2 = -CONV_RANGE; j2 <= CONV_RANGE; j2++)
                        if (i + i2 >= 0 && j + j2 >= 0 && i + i2 < IMAGE_DIM && j + j2 < IMAGE_DIM) {
                            tmp_ans += Conv1_W[CONV_MID + i2][CONV_MID + j2][0][k] * imageArray[i + i2][j + j2];
                            calc_cnt++;
                        }
                tmp_ans += Conv1_B[k];
                calc_cnt++;
                tmp_ans = RELU(tmp_ans);
                calc_cnt++;
                Conv1_Image[i][j][k] = tmp_ans;
            }
}

double max(double x1, double x2, double x3, double x4) {
    double ans = x1;
    ans = (x2 > ans) ? x2 : ans;
    ans = (x3 > ans) ? x3 : ans;
    ans = (x4 > ans) ? x4 : ans;
    return ans;
}

void MaxPool1() {
    int i, j, k;
    for (i = 0; i < IMAGE_DIM / 2; i++)
        for (j = 0; j < IMAGE_DIM / 2; j++)
            for (k = 0; k < CONV1_OUT_DIM; k++)
                Pool1_Image[i][j][k] = max(Conv1_Image[i * 2][j * 2][k],
                    Conv1_Image[i * 2 + 1][j * 2][k],
                    Conv1_Image[i * 2][j * 2 + 1][k],
                    Conv1_Image[i * 2 + 1][j * 2 + 1][k]);
}

void Conv2() {
    int i, j, k;
    int i2, j2, k2;
    double tmp_ans;
    for (i = 0; i < IMAGE_DIM / 2; i++)
        for (j = 0; j < IMAGE_DIM / 2; j++)
            for (k = 0; k < CONV2_OUT_DIM; k++) {
                tmp_ans = 0.0;
                for (i2 = -CONV_RANGE; i2 <= CONV_RANGE; i2++)
                    for (j2 = -CONV_RANGE; j2 <= CONV_RANGE; j2++)
                        for (k2 = -CONV_RANGE; k2 < CONV1_OUT_DIM; k2++)
                            if (i + i2 >= 0 && j + j2 >= 0 && i + i2 < IMAGE_DIM / 2 && j + j2 < IMAGE_DIM / 2) {
                                tmp_ans += Conv2_W[CONV_MID + i2][CONV_MID + j2][k2][k] * Pool1_Image[i + i2][j + j2][k2];
                                calc_cnt++;
                            }
                tmp_ans += Conv2_B[k];
                calc_cnt++;
                tmp_ans = RELU(tmp_ans);
                calc_cnt++;
                Conv2_Image[i][j][k] = tmp_ans;
            }
}
void MaxPool2() {
    int i, j, k;
    for (i = 0; i < IMAGE_DIM / 4; i++)
        for (j = 0; j < IMAGE_DIM / 4; j++)
            for (k = 0; k < CONV2_OUT_DIM; k++)
                Pool2_Image[i][j][k] = max(Conv2_Image[i * 2][j * 2][k],
                    Conv2_Image[i * 2 + 1][j * 2][k],
                    Conv2_Image[i * 2][j * 2 + 1][k],
                    Conv2_Image[i * 2 + 1][j * 2 + 1][k]);
}

void Flatten() {
    int i, j, k;
    for (i = 0; i < IMAGE_DIM / 4; i++)
        for (j = 0; j < IMAGE_DIM / 4; j++)
            for (k = 0; k < CONV2_OUT_DIM; k++) {
                Flat_Image[i*(IMAGE_DIM / 4)*CONV2_OUT_DIM + j * CONV2_OUT_DIM + k] = Pool2_Image[i][j][k];
                calc_cnt++;
            }
}
void Fc1() {
    int i, j;
    double tmp_ans;
    for (i = 0; i < FC1_OUT_DIM; i++) {
        tmp_ans = 0.0;
        for (j = 0; j < (IMAGE_DIM / 4)*(IMAGE_DIM / 4)*CONV2_OUT_DIM; j++) {
            tmp_ans += Flat_Image[j] * Fc1_W[j][i];
            calc_cnt++;
        }
        tmp_ans += Fc1_B[i];
        calc_cnt++;
        tmp_ans = RELU(tmp_ans);
        calc_cnt++;
        FC1_Image[i] = tmp_ans;
    }
}
void Fc2() {
    int i, j;
    double tmp_ans;
    for (i = 0; i < FC2_OUT_DIM; i++) {
        tmp_ans = 0.0;
        for (j = 0; j < FC1_OUT_DIM; j++) {
            tmp_ans += FC1_Image[j] * Fc2_W[j][i];
            calc_cnt++;
        }
        tmp_ans += Fc2_B[i];
        calc_cnt++;
        FC2_Image[i] = tmp_ans;
    }
}
void Get_Answer() {
    double max = FC2_Image[0];
    int max_point = 0;
    int i;
    for (i = 1; i < FC2_OUT_DIM; i++)
        if (FC2_Image[i] > max) {
            max = FC2_Image[i];
            max_point = i;
        }
    ans = max_point;

    double sum = 0;
    for (i = 0; i < FC2_OUT_DIM; i++) {
        Softmax[i] = exp(FC2_Image[i]);
        sum += Softmax[i];
    }
    for (i = 0; i < FC2_OUT_DIM; i++)
        Softmax[i] /= sum;
}

 void convertImageTo2DArray(uint16_t* image, uint16_t** imageArray)
{
    for (int i = 0; i < IMAGE_HEIGHT; i++) {
        for (int j = 0; j < IMAGE_WIDTH; j++) {
            imageArray[i][j] = image[i * IMAGE_WIDTH + j];
        }
    }
}


