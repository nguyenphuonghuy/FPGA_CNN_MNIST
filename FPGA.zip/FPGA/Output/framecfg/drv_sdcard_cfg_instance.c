//
//	Software Platform Generated File
//	--------------------------------
//

#include "drv_sdcard_cfg_instance.h"


const drv_sdcard_cfg_instance_t	drv_sdcard_instance_table[1] = 
{
	{
		0,
		1,
		0,
	},
};

