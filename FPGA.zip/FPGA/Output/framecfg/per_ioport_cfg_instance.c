//
//	Software Platform Generated File
//	--------------------------------
//

#include "per_ioport_cfg_instance.h"


const per_ioport_cfg_instance_t	per_ioport_instance_table[1] = 
{
	{
		0xFF010000,
		PER_IOPORT_BUSWIDTH_8,
		2,
	},
};

