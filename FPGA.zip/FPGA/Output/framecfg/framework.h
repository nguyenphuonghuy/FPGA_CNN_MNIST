//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _FRAMEWORK_H
#define _FRAMEWORK_H


 // internal framework definitions 
#define AD_ADC_INSTANCE_COUNT			0
#define AD_DAC_INSTANCE_COUNT			0
#define AD_RTC_INSTANCE_COUNT			0
#define LCD_ADAPTOR_INSTANCE_COUNT			0
#define LOCATION_ADAPTOR_INSTANCE_COUNT			0
#define NETIF_INSTANCE_COUNT			0
#define ETHERNET_ADAPTOR_INSTANCE_COUNT			0
#define AD_GRAPHICS_INSTANCE_COUNT			0
#define AD_POINTER_INSTANCE_COUNT			0
#define BLOCKIO_ADAPTOR_INSTANCE_COUNT			2
#define KEYBOARD_ADAPTOR_INSTANCE_COUNT			0
#define SERIAL_ADAPTOR_INSTANCE_COUNT			0
#define TEXTDISPLAY_ADAPTOR_INSTANCE_COUNT			0
#define AD_USBHOST_INSTANCE_COUNT			0

#endif
