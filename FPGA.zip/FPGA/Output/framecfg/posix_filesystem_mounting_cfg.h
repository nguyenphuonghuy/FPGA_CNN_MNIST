//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _POSIX_FILESYSTEM_MOUNTING_CFG_H
#define _POSIX_FILESYSTEM_MOUNTING_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */
 
#define POSIX_FILESYSTEM_MOUNTING_MOUNT_MAX			4
#define POSIX_FILESYSTEM_MOUNTING_OPEN_MAX			20
#define POSIX_FILESYSTEM_MOUNTING_NAME_MAX			30
#define POSIX_FILESYSTEM_MOUNTING_PATH_MAX			255
#define POSIX_FILESYSTEM_MOUNTING_FS_MAX			4
#define POSIX_FILESYSTEM_MOUNTING_DEVFS			1
#define POSIX_FILESYSTEM_MOUNTING_SHMFS			1
#define POSIX_FILESYSTEM_MOUNTING_FATFS			1
#define POSIX_FILESYSTEM_MOUNTING_SOCKFS			1

#endif
