//
//	Software Platform Generated File
//	--------------------------------
//

#include "posix_filesystem_cfg_instance.h"


const posix_filesystem_cfg_instance_t	posix_filesystem_instance_table[1] = 
{
	{
		1,
		"fatfs",
		1,
		"mount",
		0,
	},
};

