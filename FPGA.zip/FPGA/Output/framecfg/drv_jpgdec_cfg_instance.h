//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _DRV_JPGDEC_CFG_INSTANCE_H
#define _DRV_JPGDEC_CFG_INSTANCE_H

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

#include "drv_jpgdec_cfg.h"
#include "per_jpgdec_cfg_instance.h"


typedef struct
{
	int        			per_jpgdec;
} drv_jpgdec_cfg_instance_t;


extern const drv_jpgdec_cfg_instance_t	drv_jpgdec_instance_table[];

#endif
