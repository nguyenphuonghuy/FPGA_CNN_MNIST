//
//	Software Platform Generated File
//	--------------------------------
//

#include "per_vga32_tft_cfg_instance.h"


const per_vga32_tft_cfg_instance_t	per_vga32_tft_instance_table[1] = 
{
	{
		0xFF020000,
		-1,
		-1,
		-1,
	},
};

