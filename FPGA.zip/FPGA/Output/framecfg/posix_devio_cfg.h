//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _POSIX_DEVIO_CFG_H
#define _POSIX_DEVIO_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */
 
#define POSIX_DEVIO_STDIN_BUFTYPE_NONE			0
#define POSIX_DEVIO_STDIN_BUFTYPE_FULL			1
#define POSIX_DEVIO_STDIN_BUFTYPE_LINE			2

#define POSIX_DEVIO_STDOUT_BUFTYPE_NONE			0
#define POSIX_DEVIO_STDOUT_BUFTYPE_FULL			1
#define POSIX_DEVIO_STDOUT_BUFTYPE_LINE			2

#define POSIX_DEVIO_STDERR_BUFTYPE_NONE			0
#define POSIX_DEVIO_STDERR_BUFTYPE_FULL			1
#define POSIX_DEVIO_STDERR_BUFTYPE_LINE			2

#define POSIX_DEVIO_STDIN			0
#define POSIX_DEVIO_STDOUT			0
#define POSIX_DEVIO_STDERR			0
#define POSIX_DEVIO_DEV_MAX			8

#endif
