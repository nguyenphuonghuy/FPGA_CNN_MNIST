//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _PER_VGA32_TFT_CFG_INSTANCE_H
#define _PER_VGA32_TFT_CFG_INSTANCE_H

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

#include "per_vga32_tft_cfg.h"


#define PER_VGA32_TFT_INSTANCE_BASEADDRESS_MAX			0xFF020000
#define PER_VGA32_TFT_INSTANCE_BASEADDRESS_MIN			0xFF020000

typedef struct
{
	uintptr_t  			baseaddress;
	int8_t     			vsync_interrupt;
	int8_t     			hsync_interrupt;
	int8_t     			blank_interrupt;
} per_vga32_tft_cfg_instance_t;


extern const per_vga32_tft_cfg_instance_t	per_vga32_tft_instance_table[];

#endif
