//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _BLOCKIO_CFG_INSTANCE_H
#define _BLOCKIO_CFG_INSTANCE_H

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

#include "blockio_cfg.h"
#include "sdcard_to_blockio_cfg_instance.h"


typedef struct
{
	const char*			name;
	int        			blockio_adaptor;
} blockio_cfg_instance_t;


extern const blockio_cfg_instance_t	blockio_instance_table[];

#endif
