//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _DRV_SDCARD_CFG_INSTANCE_H
#define _DRV_SDCARD_CFG_INSTANCE_H

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

#include "drv_sdcard_cfg.h"
#include "drv_spi_cfg_instance.h"


#define DRV_SDCARD_INSTANCE_BUS_SHARING_TRUE_USED			0
#define DRV_SDCARD_INSTANCE_BUS_SHARING_FALSE_USED			1
#define DRV_SDCARD_INSTANCE_BUS_SHARING_OPTIONS_USED			1

#define DRV_SDCARD_INSTANCE_CHANNEL_MAX			1
#define DRV_SDCARD_INSTANCE_CHANNEL_MIN			1

typedef struct
{
	bool       			bus_sharing;
	uint8_t    			channel;
	int        			drv_spi;
} drv_sdcard_cfg_instance_t;


extern const drv_sdcard_cfg_instance_t	drv_sdcard_instance_table[];

#endif
