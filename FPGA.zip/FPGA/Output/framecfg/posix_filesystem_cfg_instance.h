//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _POSIX_FILESYSTEM_CFG_INSTANCE_H
#define _POSIX_FILESYSTEM_CFG_INSTANCE_H

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

#include "posix_filesystem_cfg.h"
#include "blockio_cfg_instance.h"


#define POSIX_FILESYSTEM_INSTANCE_USERMOUNT_TRUE_USED			1
#define POSIX_FILESYSTEM_INSTANCE_USERMOUNT_FALSE_USED			0
#define POSIX_FILESYSTEM_INSTANCE_USERMOUNT_OPTIONS_USED			1

#define POSIX_FILESYSTEM_INSTANCE_PARTITION_MAX			1
#define POSIX_FILESYSTEM_INSTANCE_PARTITION_MIN			1

#define POSIX_FILESYSTEM_INSTANCE_CACHE_BLOCKSIZE_MAX			512
#define POSIX_FILESYSTEM_INSTANCE_CACHE_BLOCKSIZE_MIN			512

typedef struct
{
	bool       			usermount;
	const char*			fsname;
	uint8_t    			partition;
	const char*			mountpoint;
	int        			blockio;
} posix_filesystem_cfg_instance_t;


extern const posix_filesystem_cfg_instance_t	posix_filesystem_instance_table[];

#endif
