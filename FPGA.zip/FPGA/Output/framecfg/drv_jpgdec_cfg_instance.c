//
//	Software Platform Generated File
//	--------------------------------
//

#include "drv_jpgdec_cfg_instance.h"


const drv_jpgdec_cfg_instance_t	drv_jpgdec_instance_table[1] = 
{
	{
		0,
	},
};

