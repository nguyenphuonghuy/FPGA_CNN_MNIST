//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _FATFS_CFG_H
#define _FATFS_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */
 
#define FATFS_MOUNT_MAX			4
#define FATFS_CACHE_ELEM			3
#define FATFS_USE_LFN			0

#endif
