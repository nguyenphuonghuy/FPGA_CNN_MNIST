//
//	Software Platform Generated File
//	--------------------------------
//

#include "sdcard_to_blockio_cfg_instance.h"


const sdcard_to_blockio_cfg_instance_t	sdcard_to_blockio_instance_table[1] = 
{
	{
		0,
		0,
	},
};

