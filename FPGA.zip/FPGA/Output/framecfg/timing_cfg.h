//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _TIMING_CFG_H
#define _TIMING_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */
 
#define TIMING_USETIMERS			0

#endif
