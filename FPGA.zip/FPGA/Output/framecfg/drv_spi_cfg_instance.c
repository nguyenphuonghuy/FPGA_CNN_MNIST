//
//	Software Platform Generated File
//	--------------------------------
//

#include "drv_spi_cfg_instance.h"


const drv_spi_cfg_instance_t	drv_spi_instance_table[1] = 
{
	{
		DRV_SPI_SPIMODE_MODE0,
		20000000,
		0,
		1,
		0,
	},
};

