//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _PER_JPGDEC_CFG_INSTANCE_H
#define _PER_JPGDEC_CFG_INSTANCE_H

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

#include "per_jpgdec_cfg.h"


#define PER_JPGDEC_INSTANCE_BASEADDRESS_MAX			0xFF030000
#define PER_JPGDEC_INSTANCE_BASEADDRESS_MIN			0xFF030000

typedef struct
{
	uint32_t   			baseaddress;
	int8_t     			interrupt0;
} per_jpgdec_cfg_instance_t;


extern const per_jpgdec_cfg_instance_t	per_jpgdec_instance_table[];

#endif
