//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _DRV_JPGDEC_CFG_H
#define _DRV_JPGDEC_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#define DRV_JPGDEC_INSTANCE_COUNT			1


#define DRV_JPGDEC_MAXIMUM_NUMBER_INSTANCE_USERS			0


#endif
