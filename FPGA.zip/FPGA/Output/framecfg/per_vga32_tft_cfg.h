//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _PER_VGA32_TFT_CFG_H
#define _PER_VGA32_TFT_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#define PER_VGA32_TFT_INSTANCE_COUNT			1


#define PER_VGA32_TFT_MAXIMUM_NUMBER_INSTANCE_USERS			1


#endif
