//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _SDCARD_TO_BLOCKIO_CFG_INSTANCE_H
#define _SDCARD_TO_BLOCKIO_CFG_INSTANCE_H

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

#include "sdcard_to_blockio_cfg.h"
#include "drv_sdcard_cfg_instance.h"


typedef struct
{
	int        			blockio_adaptor;
	int        			drv_sdcard;
} sdcard_to_blockio_cfg_instance_t;


extern const sdcard_to_blockio_cfg_instance_t	sdcard_to_blockio_instance_table[];

#endif
