//
//	Software Platform Generated File
//	--------------------------------
//

#include "per_spi_cfg_instance.h"


const per_spi_cfg_instance_t	per_spi_instance_table[1] = 
{
	{
		0xFF000000,
		32,
		0,
		1,
		0,
	},
};

