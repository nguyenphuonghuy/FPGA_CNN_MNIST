//
//	Software Platform Generated File
//	--------------------------------
//

#include "drv_vga_tft_cfg_instance.h"


const drv_vga_tft_cfg_instance_t	drv_vga_tft_instance_table[1] = 
{
	{
		0,
	},
};

