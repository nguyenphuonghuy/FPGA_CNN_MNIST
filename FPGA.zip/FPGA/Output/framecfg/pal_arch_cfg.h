//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _PAL_ARCH_CFG_H
#define _PAL_ARCH_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */
 
#define PAL_ARCH_3000_TIMER_INTERRUPT_NUMBER			0
#define PAL_ARCH_3000_MAXINTRS			32
#define PAL_ARCH_3000_LSLSECTION			"main"

#endif
