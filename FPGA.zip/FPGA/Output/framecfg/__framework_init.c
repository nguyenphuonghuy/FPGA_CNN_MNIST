//
//	Software Platform Generated File
//	--------------------------------
//

#include <init.h>

void framework_init (void){

	extern void pal_init(void);
	pal_init();

	extern void fs_plugin_init(void);
	fs_plugin_init();

	extern void sdcard_to_blockio_plugin_init(void);
	sdcard_to_blockio_plugin_init();

	extern void rootfs_plugin_init(void);
	rootfs_plugin_init();

	extern void fatfs_plugin_init(void);
	fatfs_plugin_init();

	extern void devfs_plugin_init(void);
	devfs_plugin_init();

	extern void posix_devio_init(void);
	posix_devio_init();

}

