//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _PER_JPGDEC_CFG_H
#define _PER_JPGDEC_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#define PER_JPGDEC_INSTANCE_COUNT			1


#define PER_JPGDEC_MAXIMUM_NUMBER_INSTANCE_USERS			1


#endif
