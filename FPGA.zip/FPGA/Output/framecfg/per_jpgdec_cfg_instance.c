//
//	Software Platform Generated File
//	--------------------------------
//

#include "per_jpgdec_cfg_instance.h"


const per_jpgdec_cfg_instance_t	per_jpgdec_instance_table[1] = 
{
	{
		0xFF030000,
		-1,
	},
};

