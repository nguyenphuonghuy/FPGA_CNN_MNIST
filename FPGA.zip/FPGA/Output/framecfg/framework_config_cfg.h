//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _FRAMEWORK_CONFIG_CFG_H
#define _FRAMEWORK_CONFIG_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */
 
#define FRAMEWORK_CONFIG_CLOCKHZ			50000000

#endif
