//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _POSIX_FILESYSTEM_CFG_H
#define _POSIX_FILESYSTEM_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#define POSIX_FILESYSTEM_INSTANCE_COUNT			1


#define POSIX_FILESYSTEM_MAXIMUM_NUMBER_INSTANCE_USERS			0

 
#define POSIX_FILESYSTEM_FATFS			1

#endif
