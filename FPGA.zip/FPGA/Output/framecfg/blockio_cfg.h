//
//	Software Platform Generated File
//	--------------------------------
//

#ifndef _BLOCKIO_CFG_H
#define _BLOCKIO_CFG_H

#ifndef  __cplusplus
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>
#endif /* __cplusplus */

#define BLOCKIO_INSTANCE_COUNT			1


#define BLOCKIO_MAXIMUM_NUMBER_INSTANCE_USERS			1


#endif
