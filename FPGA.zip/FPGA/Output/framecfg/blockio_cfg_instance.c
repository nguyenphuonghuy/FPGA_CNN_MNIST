//
//	Software Platform Generated File
//	--------------------------------
//

#include "blockio_cfg_instance.h"


const blockio_cfg_instance_t	blockio_instance_table[1] = 
{
	{
		"BLOCKIO_1",
		0,
	},
};

